package com.example.quanlicosovatchat.Model;

import java.sql.Date;

public class ThuHoi {
    private int Id;
    private int ThietBi_id;
    private Date NgayThuHoi;

    public ThuHoi(int id, int thietBi_id, Date ngayThuHoi) {
        Id = id;
        ThietBi_id = thietBi_id;
        NgayThuHoi = ngayThuHoi;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getThietBi_id() {
        return ThietBi_id;
    }

    public void setThietBi_id(int thietBi_id) {
        ThietBi_id = thietBi_id;
    }

    public Date getNgayThuHoi() {
        return NgayThuHoi;
    }

    public void setNgayThuHoi(Date ngayThuHoi) {
        NgayThuHoi = ngayThuHoi;
    }
}
