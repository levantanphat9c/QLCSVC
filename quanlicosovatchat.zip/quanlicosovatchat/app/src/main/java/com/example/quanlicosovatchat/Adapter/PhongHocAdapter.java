package com.example.quanlicosovatchat.Adapter;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.quanlicosovatchat.Model.PhongHoc;

import java.util.ArrayList;
import java.util.List;

public class PhongHocAdapter extends  BaseAdapter{
    private Context context;
    private int layout;
    private List<PhongHoc> phongHocList = new ArrayList<>();

    public PhongHocAdapter(Context context, int layout, List<PhongHoc> phongHocList) {
        this.context = context;
        this.layout = layout;
        this.phongHocList = phongHocList;
    }

    @Override
    public int getCount() {
        return phongHocList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }
    private class viewHolder{

    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
