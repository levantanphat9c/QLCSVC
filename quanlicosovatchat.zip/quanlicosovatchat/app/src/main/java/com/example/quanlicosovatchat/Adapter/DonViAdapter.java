package com.example.quanlicosovatchat.Adapter;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlicosovatchat.Model.DonVi;
import com.example.quanlicosovatchat.R;

import java.util.ArrayList;
import java.util.List;

public class DonViAdapter extends RecyclerView {
    private Context context;
    private int layout;
    private List<DonVi> donViList = new ArrayList<>();


    public DonViAdapter(@NonNull Context context) {
        super(context);
    }

    public DonViAdapter(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public DonViAdapter(@NonNull Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
}
