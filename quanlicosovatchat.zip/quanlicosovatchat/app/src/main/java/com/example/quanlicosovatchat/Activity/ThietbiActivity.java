package com.example.quanlicosovatchat.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.quanlicosovatchat.R;

public class ThietbiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thietbi);
    }
}
