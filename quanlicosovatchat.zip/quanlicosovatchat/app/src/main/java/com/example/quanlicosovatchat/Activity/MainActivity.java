package com.example.quanlicosovatchat.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.*;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.quanlicosovatchat.Adapter.DonViAdapter;
import com.example.quanlicosovatchat.Model.DonVi;
import com.example.quanlicosovatchat.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String host = "172.168.81.153";
    String urlGetData ="http://"+ host +":8080/server/getdonvi.php";
    public ArrayList<DonVi> arrayDonVi;
    public DonViAdapter adapterDonVi;
    public ListView lvDonVi ;
    public Button buttonDonVi,buttonCapPhat,buttonLoaiThietBi,buttonNguoiQuanli,buttonPhongHoc,buttonThanhLy,buttonThietBi,buttonThuHoi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AnhXa();
        clickButton();
    }

    private void GetData(String url){
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null
                , new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                for (int i =0; i< response.length();i++){
                    try{
                        JSONObject object = response.getJSONObject(i);
                        arrayDonVi.add(new DonVi(
                                object.getInt("id"),
                                object.getString("tendonvi")
                        ));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Toast.makeText(MainActivity.this, arrayDonVi.toString(), Toast.LENGTH_SHORT).show();
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Loi", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }

    private void clickButton(){
        buttonDonVi.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,DonviActivity.class);
                startActivity(intent);
            }
        });
        buttonCapPhat.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,CapphatActivity.class);
                startActivity(intent);
            }
        });
        buttonLoaiThietBi.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,LoaithietbiActivity.class);
                startActivity(intent);
            }
        });
        buttonNguoiQuanli.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,NguoiquanliActivity.class);
                startActivity(intent);
            }
        });
        buttonPhongHoc.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,PhonghocActivity.class);
                startActivity(intent);
            }
        });
        buttonThanhLy.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,ThanhlyActivity.class);
                startActivity(intent);
            }
        });
        buttonThietBi.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,ThietbiActivity.class);
                startActivity(intent);
            }
        });
        buttonThuHoi.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this,ThuhoiActivity.class);
                startActivity(intent);
            }
        });
    }

    private void AnhXa(){
        buttonDonVi = findViewById(R.id.buttonDonVi);
        buttonCapPhat = findViewById(R.id.buttonCapPhat);
        buttonLoaiThietBi = findViewById(R.id.buttonLoaiThietBi);
        buttonNguoiQuanli = findViewById(R.id.buttonNguoiQuanLi);
        buttonPhongHoc = findViewById(R.id.buttonPhongHoc);
        buttonThanhLy = findViewById(R.id.buttonThanhLy);
        buttonThietBi = findViewById(R.id.buttonThietBi);
        buttonThuHoi = findViewById(R.id.buttonThuHoi);
    }
}
