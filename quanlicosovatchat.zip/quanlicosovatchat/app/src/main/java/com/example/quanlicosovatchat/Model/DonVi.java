package com.example.quanlicosovatchat.Model;

public class DonVi {
    private int Id;
    private String TenDonVi;

    public DonVi(int id, String tenDonVi) {
        Id = id;
        TenDonVi = tenDonVi;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTenDonVi() {
        return TenDonVi;
    }

    public void setTenDonVi(String tenDonVi) {
        TenDonVi = tenDonVi;
    }
}
