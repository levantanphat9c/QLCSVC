package com.example.quanlicosovatchat.Model;

import java.sql.Date;

public class ThanhLy {
    private int Id;
    private int ThietBi_id;
    private Date NgayThanhLy;

    public ThanhLy(int id, int thietBi_id, Date ngayThanhLy) {
        Id = id;
        ThietBi_id = thietBi_id;
        NgayThanhLy = ngayThanhLy;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getThietBi_id() {
        return ThietBi_id;
    }

    public void setThietBi_id(int thietBi_id) {
        ThietBi_id = thietBi_id;
    }

    public Date getNgayThanhLy() {
        return NgayThanhLy;
    }

    public void setNgayThanhLy(Date ngayThanhLy) {
        NgayThanhLy = ngayThanhLy;
    }
}
