package com.example.quanlicosovatchat.Model;

public class NguoiQuanLi {
    private int Id;
    private String HoTen;
    private int DonVi;
    private boolean GioiTinh;
    private String DiaChi;
    private int SoDienThoai;

    public NguoiQuanLi(int id, String hoTen, int donVi, boolean gioiTinh, String diaChi, int soDienThoai) {
        Id = id;
        HoTen = hoTen;
        DonVi = donVi;
        GioiTinh = gioiTinh;
        DiaChi = diaChi;
        SoDienThoai = soDienThoai;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String hoTen) {
        HoTen = hoTen;
    }

    public int getDonVi() {
        return DonVi;
    }

    public void setDonVi(int donVi) {
        DonVi = donVi;
    }

    public boolean isGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        GioiTinh = gioiTinh;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String diaChi) {
        DiaChi = diaChi;
    }

    public int getSoDienThoai() {
        return SoDienThoai;
    }

    public void setSoDienThoai(int soDienThoai) {
        SoDienThoai = soDienThoai;
    }
}
