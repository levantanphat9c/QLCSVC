package com.example.quanlicosovatchat.Model;

import java.sql.Date;

public class CapPhat {

    private int Id;
    private int ThietBi_id;
    private int NguoiQuanLy_id;
    private int Phong;
    private int DonVi;
    private int SoLuong;
    private java.sql.Date NgayCapPhat;
    private java.sql.Date NgayThuHoi;
    private String GhiChu;

    public CapPhat(int id, int thietBi_id, int nguoiQuanLy_id, int phong, int donVi, int soLuong, Date ngayCapPhat, Date ngayThuHoi, String ghiChu) {
        Id = id;
        ThietBi_id = thietBi_id;
        NguoiQuanLy_id = nguoiQuanLy_id;
        Phong = phong;
        DonVi = donVi;
        SoLuong = soLuong;
        NgayCapPhat = ngayCapPhat;
        NgayThuHoi = ngayThuHoi;
        GhiChu = ghiChu;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getThietBi_id() {
        return ThietBi_id;
    }

    public void setThietBi_id(int thietBi_id) {
        ThietBi_id = thietBi_id;
    }

    public int getNguoiQuanLy_id() {
        return NguoiQuanLy_id;
    }

    public void setNguoiQuanLy_id(int nguoiQuanLy_id) {
        NguoiQuanLy_id = nguoiQuanLy_id;
    }

    public int getPhong() {
        return Phong;
    }

    public void setPhong(int phong) {
        Phong = phong;
    }

    public int getDonVi() {
        return DonVi;
    }

    public void setDonVi(int donVi) {
        DonVi = donVi;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }

    public Date getNgayCapPhat() {
        return NgayCapPhat;
    }

    public void setNgayCapPhat(Date ngayCapPhat) {
        NgayCapPhat = ngayCapPhat;
    }

    public Date getNgayThuHoi() {
        return NgayThuHoi;
    }

    public void setNgayThuHoi(Date ngayThuHoi) {
        NgayThuHoi = ngayThuHoi;
    }

    public String getGhiChu() {
        return GhiChu;
    }

    public void setGhiChu(String ghiChu) {
        GhiChu = ghiChu;
    }
}
