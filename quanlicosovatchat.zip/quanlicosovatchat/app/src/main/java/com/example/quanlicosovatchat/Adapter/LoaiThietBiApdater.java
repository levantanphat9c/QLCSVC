package com.example.quanlicosovatchat.Adapter;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.quanlicosovatchat.Model.LoaiThietBi;

import java.util.ArrayList;
import java.util.List;

public class LoaiThietBiApdater extends BaseAdapter{
    private Context context;
    private int layout;
    private List<LoaiThietBi> loaiThietBiList = new ArrayList<>();

    public LoaiThietBiApdater(Context context, int layout, List<LoaiThietBi> loaiThietBiList) {
        this.context = context;
        this.layout = layout;
        this.loaiThietBiList = loaiThietBiList;
    }

    @Override
    public int getCount() {
        return loaiThietBiList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    private class viewHolder{

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
