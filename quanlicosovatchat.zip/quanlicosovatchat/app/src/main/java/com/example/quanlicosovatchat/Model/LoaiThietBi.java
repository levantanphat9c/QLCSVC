package com.example.quanlicosovatchat.Model;

public class LoaiThietBi {
    private  int Id;
    private String TenLoaiThietBi;

    public LoaiThietBi(int id, String tenLoaiThietBi) {
        Id = id;
        TenLoaiThietBi = tenLoaiThietBi;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTenLoaiThietBi() {
        return TenLoaiThietBi;
    }

    public void setTenLoaiThietBi(String tenLoaiThietBi) {
        TenLoaiThietBi = tenLoaiThietBi;
    }
}
