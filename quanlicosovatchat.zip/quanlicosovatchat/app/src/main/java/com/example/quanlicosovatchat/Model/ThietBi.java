package com.example.quanlicosovatchat.Model;

import java.sql.Date;

public class ThietBi {
    private int Id;
    private String TenThietBi;
    private String NhaSanXuat;
    private Date NgayNhap;
    private int DonGia;
    private int SoLuong;
    private int TongTien;
    private int LoaiThietBi_id;
    private String GhiChu;
    private String TinhTrang;

    public ThietBi(int id, String tenThietBi, String nhaSanXuat, Date ngayNhap, int donGia, int soLuong, int tongTien, int loaiThietBi_id, String ghiChu, String tinhTrang) {
        Id = id;
        TenThietBi = tenThietBi;
        NhaSanXuat = nhaSanXuat;
        NgayNhap = ngayNhap;
        DonGia = donGia;
        SoLuong = soLuong;
        TongTien = tongTien;
        LoaiThietBi_id = loaiThietBi_id;
        GhiChu = ghiChu;
        TinhTrang = tinhTrang;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTenThietBi() {
        return TenThietBi;
    }

    public void setTenThietBi(String tenThietBi) {
        TenThietBi = tenThietBi;
    }

    public String getNhaSanXuat() {
        return NhaSanXuat;
    }

    public void setNhaSanXuat(String nhaSanXuat) {
        NhaSanXuat = nhaSanXuat;
    }

    public Date getNgayNhap() {
        return NgayNhap;
    }

    public void setNgayNhap(Date ngayNhap) {
        NgayNhap = ngayNhap;
    }

    public int getDonGia() {
        return DonGia;
    }

    public void setDonGia(int donGia) {
        DonGia = donGia;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }

    public int getTongTien() {
        return TongTien;
    }

    public void setTongTien(int tongTien) {
        TongTien = tongTien;
    }

    public int getLoaiThietBi_id() {
        return LoaiThietBi_id;
    }

    public void setLoaiThietBi_id(int loaiThietBi_id) {
        LoaiThietBi_id = loaiThietBi_id;
    }

    public String getGhiChu() {
        return GhiChu;
    }

    public void setGhiChu(String ghiChu) {
        GhiChu = ghiChu;
    }

    public String getTinhTrang() {
        return TinhTrang;
    }

    public void setTinhTrang(String tinhTrang) {
        TinhTrang = tinhTrang;
    }
}
