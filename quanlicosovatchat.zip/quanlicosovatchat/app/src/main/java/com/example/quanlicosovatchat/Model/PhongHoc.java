package com.example.quanlicosovatchat.Model;

public class PhongHoc {
    private int Id;
    private String TenPhong;

    public PhongHoc(int id, String tenPhong) {
        Id = id;
        TenPhong = tenPhong;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTenPhong() {
        return TenPhong;
    }

    public void setTenPhong(String tenPhong) {
        TenPhong = tenPhong;
    }
}
